package com.eage.validation.util;

public class Constants {

    public static final class Request {
        public static final String QUESTION = "Please sum the numbers " ;
    }

    public static final class Error {
        public static final String INCORRECT_ANSWER = "Incorrect answer" ;
    }

}
