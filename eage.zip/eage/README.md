Eage service :

Objective of this application is to make sure our
application is accessed by humans and not by any computers or bot.

1) Swagger ui :
   http://localhost:7080/eage/swagger-ui.html

2) Actuator :
   http://localhost:7080/eage/actuator


